package com.revature.tutorial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TutorialBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(TutorialBackendApplication.class, args);
	}

}
