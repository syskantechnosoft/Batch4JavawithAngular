export class Payment {
    name: string
    detail: string

    constructor (name: string, detail: string) {
        this.name = name;
        this.detail = detail;
    }
}
